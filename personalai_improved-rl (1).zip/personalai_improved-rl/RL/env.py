from src.utils.data_structs import *
from typing import List, Tuple, Optional, Dict, Any
from functools import lru_cache

import numpy as np
import gymnasium as gym
from gymnasium import spaces


def _exec_query(connector, q: str):
    # Neo4jGraphConnector in v2: connector.execute_query(...) -> List[Record]
    if hasattr(connector, "execute_query"):
        return connector.execute_query(q)
    # KuzuGraphConnector legacy path: connector.conn.execute(...) -> QueryResult
    if hasattr(connector, "conn"):
        return connector.conn.execute(q)
    raise TypeError("Unsupported graph connector interface")


def _extract_ids(raw, col: str) -> List[str]:
    # Kuzu: QueryResult .get_as_df()
    if hasattr(raw, "get_as_df"):
        return raw.get_as_df()[col].tolist()
    ids = []
    for r in raw:
        try:
            ids.append(r[col])     
        except Exception:
            ids.append(getattr(r, "data", lambda: r)()[col])
    return ids


@lru_cache(maxsize=1)
def get_all_triplets(connector):
    #q = 'MATCH ()-[r]->() WHERE exists(r.t_id) RETURN r.t_id AS t_id;' 
    q = 'MATCH ()-[r]->() WHERE r.t_id IS NOT NULL RETURN r.t_id AS t_id;' #
    raw = _exec_query(connector, q)
    ids = _extract_ids(raw, 't_id')
    return connector.read(ids) 


def find_eq_rq_E(kg):
    connector = kg.graph_struct.db_conn
    triplets = get_all_triplets(connector)
    agg = {}
    num_outgoing_edges = {}
    for t in triplets:
        if t.relation.type == RelationType.simple:
            if (t.start_node.name, t.relation.name) not in agg:
                agg[(t.start_node.name, t.relation.name)] = [t.start_node, t.relation, [t.end_node]]
            else:
                agg[(t.start_node.name, t.relation.name)][-1] += [t.end_node]
            num_outgoing_edges[t.start_node.id] = num_outgoing_edges.get(t.start_node.id, 0) + 1
    eq_rq_E = list(agg.values())
    # filter those where num_outgoing_edges <= 1 (otherwise it is terminal state during training)
    eq_rq_E = [t for t in eq_rq_E if num_outgoing_edges[t[0].id] > 1]
    return eq_rq_E




class Trajectory:
    def __init__(self, eq, rq, es, E=tuple()):   # query entity, query relation, start entity, end entities (omit if unknown)
        self.step_count = 0
        self.query = [eq, rq]
        self.target_ids = {e.id for e in E}
        self.path: List[Node | Relation] = [es]
        self.options: List[List[Relation, Node]] = None

    @property
    def reward(self):
        return int(self.path[-1].id in self.target_ids)

    def append(self, r, e):
        self.path.extend([r, e])
        self.options = None
        self.step_count += 1




class PathEnv(gym.Env):
    def __init__(self, 
                 kg_model, 
                 n_env,                                                           # num of parallel trajectories
                 max_hops: int = 20,                                              # max length of trajectory
                 initial_state: Optional[List[List[Node | Relation]]] = None,     # if specified, env resets to this state instead of sampling, each element is [query entity, query relation, start entity]
                 seed: Optional[int] = None):                                     # random seed for sampling
        super().__init__()
        self.conn = kg_model.graph_struct.db_conn
        self.graph_emb = kg_model.graph_embeddings
        self.all_triples = find_eq_rq_E(kg_model)  # [eq, rq, E]
        self.all_states = [[t[0], t[1], t[0], t[2]] for t in self.all_triples]  # [eq, rq, es, E]
        self.initial_state = initial_state

        self.rng = np.random.default_rng(seed=seed)
        self.n_env = n_env
        self.max_hops = max_hops
        self.trajectories = [None] * n_env

        self.observation_space = spaces.Dict(
            {
                "query": spaces.Text(min_length=0, max_length=128),
                "path": spaces.Sequence(spaces.Text(min_length=0, max_length=128)),
                "options": spaces.Sequence(spaces.Text(min_length=0, max_length=128)),
            }
        )
        self.action_space = spaces.Discrete(1 + len(self.all_triples))


    @staticmethod
    def _get_outgoing(conn, entities: List[Node], exclude_relations: List[Relation]):
        ids = ", ".join(f'"{i}"' for i in set([e.id for e in entities]))
        q = f'''
            MATCH (n1)-[rel]->(n2)
            WHERE n1.str_id IN [{ids}] AND rel.t_id IS NOT NULL
            RETURN n1, rel, n2;
            '''
        raw = _exec_query(conn, q)
        triplets = conn.parse_query_triplets_output(raw)
        out = []
        # TODO: USE ONLY SIMPLE RELATIONS?
        for e, r in zip(entities, exclude_relations):
            out.append([[t.relation, t.end_node] for t in triplets if 
                        t.start_node == e and t.relation.type == RelationType.simple and t.relation.id != r.id])
        return out  # [list[n_out_1, 2], list[n_out_2, 2], ...]


    @staticmethod
    def obs(trajs: List[Trajectory], emb_db = None) -> Dict[str, List[np.ndarray]]:
        # if no embeddings, return strings
        if emb_db is None:
            return {
                "query": [[t.query[0].name, t.query[1].name] for t in trajs],
                "path": [[x.name for x in reversed(t.path)] for t in trajs],   # path in REVERSED order
                "options": [[[x.name, y.name] for x, y in t.options] for t in trajs]
            }

        # retrieve embeddings
        obs = {
            "query": [t.query for t in trajs],
            "path": [list(reversed(t.path)) for t in trajs],   # path in REVERSED order
            "options": [t.options for t in trajs]
        }

        node_embs = []
        rel_embs = []

        def read(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    read(v)
            elif isinstance(x, list):
                for v in x:
                    read(v)
            elif isinstance(x, Node):
                node_embs.append(x.id)
            elif isinstance(x, Relation):
                rel_embs.append(x.id)
            else:
                raise ValueError
            
        node_i, rel_i = 0, 0
        def create(x):
            nonlocal node_i, rel_i
            if isinstance(x, dict):
                return {k: create(v) for k, v in x.items()}
            elif isinstance(x, list):
                return [create(v) for v in x]
            elif isinstance(x, Node):
                emb = node_embs[node_i]
                node_i += 1
                return emb
            elif isinstance(x, Relation):
                emb = rel_embs[rel_i]
                rel_i += 1
                return emb
            else:
                raise ValueError 

        read(obs)
        node_embs = emb_db.read("nodes", node_embs, NodeType.object)
        rel_embs = emb_db.read("triplets", rel_embs)
        obs = create(obs)

        obs_vec = {
            "query": [np.array(t, dtype=np.float32) for t in obs["query"]],
            "path": [np.array(t, dtype=np.float32) for t in obs["path"]],
            "options": [np.array(t, dtype=np.float32).reshape(-1, 2, emb_db.emb_dim) for t in obs["options"]]  # reshape in case of 0 options
        }

        return obs_vec


    def update_options(self):
        # update options where needed
        trajs = [t for t in self.trajectories if t.options is None]
        eq = [t.path[-1] for t in trajs]
        rq = [t.query[1] for t in trajs]
        options = PathEnv._get_outgoing(self.conn, eq, rq)
        for t, o in zip(trajs, options):
            t.options = o
        


    def reset(self, ids: Optional[List[int]] = None):
        if ids is None:
            ids = list(range(self.n_env))
        
        if self.initial_state is None:
            # sample and create new trajectories
            sample_ids = self.rng.choice(len(self.all_states), self.n_env, replace=True)
            states = [self.all_states[i] for i in sample_ids] # [eq, rq, es, E]
        else:
            # get initial state
            states = self.initial_state

        for i in ids:
            self.trajectories[i] = Trajectory(*states[i])
        # update options
        self.update_options()
        # create observations
        obs = PathEnv.obs(self.trajectories, self.graph_emb)
        info = {}
        return obs, info
    

    def step(self, actions: List[int]):
        terminated = [False] * self.n_env
        reward = [0.0] * self.n_env

        for i in range(self.n_env):
            t = self.trajectories[i]
            action = actions[i]
            if action == 0 or t.step_count >= self.max_hops:
                terminated[i] = True
                reward[i] = t.reward
            elif action == 1:
                # TODO: how to pass Relation in reversed direction?
                # rel, next_e = Relation(f"reversed({t.path[-2].name})", RelationType.simple), t.path[-3]
                rel, next_e = t.path[-2], t.path[-3]
                t.append(rel, next_e)
            else:
                rel, next_e = t.options[action - 2]
                t.append(rel, next_e)
        
        # reset trajectories that are done (options will be updated in all envs)
        obs, _ = self.reset(np.nonzero(terminated)[0])
        infos = [{} for _ in range(self.n_env)]   #
        
        return obs, reward, terminated, infos     #
