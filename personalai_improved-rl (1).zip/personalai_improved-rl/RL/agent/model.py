import torch
import torch.nn as nn
import numpy as np



class PositionalEncoding(torch.nn.Module):
    def __init__(self, dim, max_length = None):
        super().__init__()
        if max_length is None:
            freq = torch.exp(-np.log(10000.0) * torch.arange(0, dim, 2) / dim)
        else:
            c = np.log(2*np.pi / (max_length-1)) * dim/(dim-2)
            freq = torch.exp(c * torch.arange(0, dim, 2) / dim)
        pe = torch.zeros(1, 1, dim)
        self.register_buffer("freq", freq)
        self.register_buffer("pe", pe)
        
    def forward(self, length):
        pos = torch.arange(0, length, device=self.pe.device).view(1, -1, 1)
        pe = self.pe.expand(1, length, -1).contiguous()
        pe[:, :, 0::2] = torch.sin(self.freq * pos)
        pe[:, :, 1::2] = torch.cos(self.freq * pos)
        return pe



class PolicyNetwork(nn.Module):
    def __init__(self, 
                 embedding_dim: int = 384, 
                 hidden_dim: int = 512, 
                 num_heads: int = 8, 
                 feedforward_dim: int = 2048,
                 num_layers: int = 10,
                 pos_enc_dim: int = 8,
                 max_path_length: int = 100):
        super().__init__()
        self.embedding_dim = embedding_dim

        pos_dim = 32

        # Query encoder
        self.query_token = torch.nn.Parameter(torch.randn(1, 1, pos_dim)/np.sqrt(pos_dim))
        self.query_inj = torch.nn.Linear(2 * embedding_dim + pos_dim, hidden_dim)

        # Path encoder
        self.path_token = torch.nn.Parameter(torch.randn(1, 1, pos_dim-pos_enc_dim)/np.sqrt(pos_dim-pos_enc_dim))
        self.pos_encoder = PositionalEncoding(pos_enc_dim, max_length=max_path_length)
        self.register_buffer("type_encoding", (torch.arange(max_path_length) % 2).view(1, -1, 1))
        self.path_inj = torch.nn.Linear(embedding_dim + pos_dim + 1, hidden_dim)

        # Option encoder
        self.option_token = torch.nn.Parameter(torch.randn(1, 1, pos_dim)/np.sqrt(pos_dim))
        self.end_token = torch.nn.Parameter(torch.randn(1, 1, 2 * embedding_dim)/np.sqrt(2 * embedding_dim))
        self.step_back_token = torch.nn.Parameter(torch.randn(1, 1, 2 * embedding_dim)/np.sqrt(2 * embedding_dim))
        self.option_inj = torch.nn.Linear(2 * embedding_dim + pos_dim, hidden_dim)

        # Joint encoder
        self.encoder = torch.nn.TransformerEncoder(
            torch.nn.TransformerEncoderLayer(
                d_model=hidden_dim, nhead=num_heads, dim_feedforward=feedforward_dim, batch_first=True, dropout=0, 
            ),
            num_layers=num_layers
        )

        self.value_head = torch.nn.Linear(hidden_dim, 1)
        self.policy_head = torch.nn.Linear(hidden_dim, 1)


    @property
    def device(self):
        """Infer which device this policy lives on by inspecting its parameters."""
        return next(iter(self.parameters())).device


    @staticmethod
    def get_pad_mask(lengths: torch.IntTensor, max_length: int = None):
        # true = invalid, false = valid
        max_length = max_length or lengths.max()
        return torch.arange(max_length, device=lengths.device).view(1, -1) >= lengths.view(-1, 1)  # (N, L)


    def forward(self, 
                query: torch.Tensor, 
                path: torch.Tensor,
                path_lengths: torch.Tensor,
                options: torch.Tensor, 
                num_options: torch.Tensor) -> torch.Tensor:
        """
        Args:
            query: (N, 2, D_emb)
            path: (N, L, D_emb)
            path_lengths: (N,)
            options: (N, N_opt, 2, D_emb)
            num_options: (N,)

        Returns:
            pi: (N, N_opt+2)    # end + step_back + options
            value: (N,)
        """
        N, L, _ = path.shape
        N_opt = options.shape[1]
        D_emb = query.shape[-1]


        if isinstance(path_lengths, list):
            path_lengths = torch.tensor(path_lengths, device=path.device)  # (N,)
        query = query.view(N, 1, -1)  # (N, 1, 2 * D_emb)
        query = torch.cat([self.query_token.expand(N, -1, -1), query], dim=-1)
        query_features = self.query_inj(query)  #  (N, 1, D)
        query_mask = torch.full((N, 1), False, device=query.device)


        path_pos_enc = self.pos_encoder(L).expand(N, -1, -1)  # (N, L, D_pos)
        path = torch.cat([self.path_token.expand(N, L, -1), self.type_encoding[:, :L].expand(N, -1, -1), path_pos_enc, path], dim=-1)
        path_features = self.path_inj(path)   # (N, L, D)
        path_mask = PolicyNetwork.get_pad_mask(path_lengths, L)  # (N, L)


        if isinstance(num_options, list):
            num_options = torch.tensor(num_options, device=options.device)
        options = options.view(N, N_opt, 2 * D_emb)  # (N, N_opt, 2 * D_emb)
        options = torch.cat([self.end_token.expand(N, -1, -1), self.step_back_token.expand(N, -1, -1), options], dim=1)  # (N, N_opt+2, 2 * D_emb)
        options = torch.cat([self.option_token.expand(N, N_opt+2, -1), options], dim=-1)
        options_features = self.option_inj(options)  # (N, N_opt+2, D)
        options_mask = torch.cat([
            torch.full((N, 1), False, device=options.device),
            (path_lengths < 3).view(N, 1),
            PolicyNetwork.get_pad_mask(num_options, N_opt)
        ], dim=1)  # (N, N_opt+2)

        mask = torch.cat([query_mask, path_mask, options_mask], dim=1)  # (N, L + N_opt + 3)
        features = torch.cat([query_features, path_features, options_features], dim=1)  # (N, L + N_opt + 3, D)

        logits = self.encoder(features, src_key_padding_mask=mask)  # (N, L + N_opt + 3, D)
        value = self.value_head(logits[:, 0]).view(-1)    # (N,)
        pi_logits = self.policy_head(logits[:, -(N_opt+2):]).view(N, -1)  # (N, N_opt+2)
        pi_logits.masked_fill_(options_mask, float('-inf'))
        pi = torch.distributions.Categorical(logits=pi_logits)
        return pi, value
