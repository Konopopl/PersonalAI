from dataclasses import dataclass, field
from sentence_transformers import SentenceTransformer
from typing import Dict, List
import torch



@dataclass
class EmbedderModelConfig:
    model_name_or_path: str = 'models/intfloat/multilingual-e5-small'
    prompts: Dict = field(default_factory=lambda: {
                          "query": "query: ", "passage": "passage: "})
    device: str = 'cpu'
    normalize_embeddings: bool = True


class EmbedderModel:

    # TODO: MAKE IT TRAINABLE
    def __init__(self, config: EmbedderModelConfig = None) -> None:
        self.config = EmbedderModelConfig() if config is None else config
        self.model = SentenceTransformer(
            self.config.model_name_or_path, device=self.config.device,
            prompts=self.config.prompts
        )

    def encode(self, queries: List[str], **kwargs) -> torch.Tensor:
        output = self.model.encode(
            queries, normalize_embeddings=self.config.normalize_embeddings, convert_to_tensor=True, **kwargs)
        return output