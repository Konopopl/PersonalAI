import torch
import numpy as np
from .model import PolicyNetwork
from .embedder import EmbedderModel



class Agent(torch.nn.Module):
    def __init__(self, embedding_dim):
        super().__init__()
        self.embedder = EmbedderModel()
        self.policy_net = PolicyNetwork(embedding_dim)


    def encode(self, obs: dict) -> dict:
        # obs:
        # {
        #     "query": list[list[[str]],            env, [entity, rel]
        #     "path": list[list[str]],              env, path
        #     "options": list[list[list[str]]]      env, options, [rel, entity]
        # }
        # OR
        # {
        #     "query": list[np.ndarray],          env, [entity, rel]
        #     "path": list[np.ndarray],           env, path
        #     "options": list[np.ndarray]         env, options, [rel, entity]
        # }

        data = []
        n_env = len(obs["query"])
        path_lengths = [len(x) for x in obs["path"]]
        num_options = [len(x) for x in obs["options"]]

        if isinstance(obs["query"][0], list):
            # Flatten
            for x in obs["query"]:
                data.extend(x)        # n_env * 2
            for x in obs["path"]:
                data.extend(x)        # sum(path_lengths)
            for x in obs["options"]:
                for y in x:
                    data.extend(y)    # 2 * sum(num_options)
            
            # Encode
            encoded_data = self.embedder.encode(data)  # [:, D_emb]
            query_seq, path_seqs, option_seqs = torch.split(encoded_data, [n_env * 2, sum(path_lengths), sum(num_options) * 2], dim=0)

            # Unflatten and padding
            ## query
            queries = query_seq.view(n_env, 2, -1)    # (N, 2, D_emb)
            ## path
            path_seqs = torch.split(path_seqs, path_lengths, dim=0)
            paths = torch.nn.utils.rnn.pad_sequence(path_seqs, batch_first=True)   # (N, L, D_emb)
            ## options
            option_seqs = torch.split(option_seqs, [n * 2 for n in num_options], dim=0)
            option_seqs = [x.view(-1, 2, x.shape[-1]) for x in option_seqs]
            options = torch.nn.utils.rnn.pad_sequence(option_seqs, batch_first=True)  # (N, N_opt, 2, D_emb)

        elif isinstance(obs["query"][0], np.ndarray):
            queries = torch.tensor(np.array(obs["query"]), device=self.policy_net.device)  # (N, 2, D_emb)
            paths = [torch.tensor(p, device=self.policy_net.device) for p in obs["path"]]
            paths = torch.nn.utils.rnn.pad_sequence(paths, batch_first=True)   # (N, L, D_emb)
            options = [torch.tensor(o, device=self.policy_net.device) for o in obs["options"]]
            options = torch.nn.utils.rnn.pad_sequence(options, batch_first=True)  # (N, N_opt, 2, D_emb)

        else:
            raise ValueError

        vec_obs = {
            "query": queries,
            "path": paths,
            "options": options,
            "path_lengths": path_lengths,
            "num_options": num_options
        }

        return vec_obs


    def forward(self, obs):
        pi, values = self.policy_net(**obs)
        actions = pi.sample()
        log_prob = pi.log_prob(actions)
        return actions, values, log_prob

    
    def predict(self, obs, deterministic: bool = False) -> int:
        with torch.no_grad():
            pi, _ = self.policy_net(**obs)
            if deterministic:
                actions = pi.mode
            else:
                actions = pi.sample()
            return actions
    

    def predict_values(self, obs):
        _, values = self.policy_net(**obs)
        return values


    def evaluate_actions(self, obs, actions):
        """
        Evaluate actions according to the current policy
        """
        pi, values = self.policy_net(**obs)
        log_prob = pi.log_prob(actions)
        entropy = pi.entropy()
        return values, log_prob, entropy