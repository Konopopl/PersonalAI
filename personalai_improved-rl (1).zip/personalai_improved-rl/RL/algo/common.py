import numpy as np
from typing import  Any, Optional, Tuple, Callable



def evaluate_policy(
    agent,
    env,
    n_eval_episodes: int = 10,
    deterministic: bool = False,
    return_paths: bool = False,
    callback: Optional[Callable[[dict[str, Any], dict[str, Any]], None]] = None,
) -> Tuple[float, float]:

    n_envs = env.n_env
    episode_rewards = []
    episode_lengths = []

    episode_counts = np.zeros(n_envs, dtype="int")
    # As in SB3: "Divides episodes among different sub environments in the vector as evenly as possible"
    episode_count_targets = np.array([(n_eval_episodes + i) // n_envs for i in range(n_envs)], dtype="int")

    current_rewards = np.zeros(n_envs)
    current_lengths = np.zeros(n_envs, dtype="int")
    observations, _ = env.reset()
    episode_starts = np.ones((env.n_env,), dtype=bool)
    episode_paths = [[t.path[0]] for t in env.trajectories]

    while (episode_counts < episode_count_targets).any():
        tensor_obs = agent.encode(observations)
        actions = agent.predict(
            tensor_obs,
            deterministic=deterministic
        ) #expect return type: List[int]
        new_observations, rewards, dones, infos = env.step(actions)
        current_rewards += rewards
        current_lengths += 1

        for i in range(n_envs):
            episode_starts[i] = dones[i]
            if episode_counts[i] < episode_count_targets[i]:
                if callback is not None:
                    reward = rewards[i]
                    done = dones[i]
                    info = infos[i]
                    callback(locals(), globals())

                if dones[i]:
                    episode_rewards.append(current_rewards[i])
                    episode_lengths.append(current_lengths[i])
                    episode_counts[i] += 1
                    current_rewards[i] = 0
                    current_lengths[i] = 0
                else:
                    if return_paths:
                        episode_paths[i].extend(env.trajectories[i].path[-2:])

        observations = new_observations

    # Statistics calculation:
    metrics = {
        "mean_reward": np.mean(episode_rewards),
        "std_reward": np.std(episode_rewards),
        "mean_episode_length": np.mean(episode_lengths),
    }

    if return_paths:
        return metrics, episode_paths
    else:
        return metrics