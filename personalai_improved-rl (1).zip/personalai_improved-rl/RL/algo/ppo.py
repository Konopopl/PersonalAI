import torch.optim as optim
import numpy as np
from typing import Tuple, Dict, Any, List, Optional
import torch
import torch.nn as nn
from collections import defaultdict
from dataclasses import dataclass
from torch.utils.tensorboard import SummaryWriter
from .common import evaluate_policy
import uuid



@dataclass
class Rollout:
    observations: Dict[str, torch.Tensor]
    actions: torch.Tensor
    old_log_probs: torch.Tensor
    values: torch.Tensor
    returns: torch.Tensor
    advantages: torch.Tensor



class RolloutStorage:
    def __init__(self, num_steps: int, num_envs: int, device: torch.device, normalize_advantages: bool = False):
        self.num_steps = num_steps
        self.num_envs = num_envs
        self.device = device
        self.normalize_advantages = normalize_advantages

        # Initialize storage buffers
        self.observations = {}
        self.actions = torch.zeros((num_steps, num_envs), dtype=torch.long, device=device)  # (N,)
        self.log_probs = torch.zeros((num_steps, num_envs), device=device)  # (N,) - log probs are scalar per sample
        self.rewards = torch.zeros((num_steps, num_envs), device=device)  # (N,) - rewards are scalar per sample
        self.dones = torch.zeros((num_steps, num_envs), device=device)  # (N,) - dones are boolean per sample
        self.values = torch.zeros((num_steps, num_envs), device=device)  # (N,) - values

        # Advantages and returns
        self.advantages = torch.zeros((num_steps, num_envs), device=device)  # (N,) for computation
        self.returns = torch.zeros((num_steps, num_envs), device=device)  # (N,) for computation

        self.step = 0


    def add(self,
            obs: Dict[str, torch.Tensor],
            action: torch.Tensor,  # (N,) - action_id from specification
            log_prob: torch.Tensor,  # (N,) - log probability
            value: torch.Tensor,  # (N,) - value
            reward: torch.Tensor,  # (N,) - reward
            done: torch.Tensor):  # (N,) - done flag
        """Add a single step of experience for all environments"""
        for k, v in obs.items():
            self.observations[k] = self.observations.get(k,[]) + [v]
        self.actions[self.step] = action  # (N,)
        self.log_probs[self.step] = log_prob  # (N,)
        self.values[self.step] = value  # (N,)
        self.rewards[self.step] = reward
        self.dones[self.step] = done

        self.step += 1


    def compute_returns_and_advantages(self, next_values: torch.Tensor, gamma: float, gae_lambda: float):
        """Compute returns and advantages using GAE for parallel environments"""
        last_advantage = torch.zeros(self.num_envs, device=self.device)  # (num_envs,)

        # Iterate backwards through time steps
        for t in reversed(range(self.num_steps)):
            if t == self.num_steps - 1:
                next_values_t = next_values  # (num_envs,)
            else:
                next_values_t = self.values[t + 1]  # (num_envs,)

            # Compute TD residual and advantages
            delta = self.rewards[t] + gamma * next_values_t * (1 - self.dones[t]) - self.values[t]
            # Compute advantage using the previous timestep's advantage
            self.advantages[t] = delta + gamma * gae_lambda * (1 -self.dones[t]) * last_advantage

            # Update last_advantage for next iteration
            last_advantage = self.advantages[t]

        # Compute returns
        self.returns = self.advantages + self.values

        # Normalize advantages across all environments and time steps
        if self.normalize_advantages:
            self.advantages = (self.advantages - self.advantages.mean()) / (self.advantages.std() + 1e-8)


    def get_minibatches(self, minibatch_size: int):
        """Generate minibatches for training with proper shapes"""
        # Flatten all experiences while maintaining inner dimensions
        flat_observations = {}
        for k, v in self.observations.items():
            if isinstance(v[0], torch.Tensor):
                x_pad = torch.nn.utils.rnn.pad_sequence([x.transpose(0,1) for x in v])  # [L, Ns, Ne, ...]
                x_pad = x_pad.view(x_pad.shape[0], -1, *x_pad.shape[3:]).transpose(0, 1)  # [Ns * Ne, L, ...]
                flat_observations[k] = x_pad
            if isinstance(v[0], list):
                flat_observations[k] = torch.tensor(sum(v, start=[]), device=self.device)
        flat_actions = self.actions.view(-1)  # (B,)
        flat_log_probs = self.log_probs.view(-1)  # (B,)
        flat_advantages = self.advantages.view(-1)  # (B,)
        flat_returns = self.returns.view(-1)  # (B,)
        flat_values = self.values.view(-1)  # (B,)

        # Generate random indices
        batch_size = flat_actions.shape[0]
        indices = torch.randperm(batch_size, device=self.device)

        for mb_indices in indices.split(minibatch_size):

            minibatch = Rollout(
                observations = {k: v[mb_indices] for k, v in flat_observations.items()},
                actions = flat_actions[mb_indices],
                old_log_probs = flat_log_probs[mb_indices],
                values = flat_values[mb_indices],
                returns = flat_returns[mb_indices],
                advantages = flat_advantages[mb_indices]
            )

            yield minibatch


    def clear(self):
        """Reset for new rollouts"""
        self.observations = {}
        self.step = 0




class PPO:
    def __init__(self,
                 env,
                 test_env,
                 agent,
                 max_grad_clip_norm: float = 1.0,
                 value_coef: float = 0.5,
                 ent_coef: float = 1e-4,
                 batch_size: int = 256,
                 num_steps: int = 2048,
                 num_epochs: int = 5,
                 clip_epsilon: float = 0.2,
                 gamma: float = 0.99,
                 gae_lambda: float = 0.95,
                 learning_rate: float = 1e-5,
                 device: torch.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu'),
                 log_dir: str = "runs"):

        self.env = env
        self.test_env = test_env
        self.agent = agent.to(device)
        self.device = device

        # PPO hyperparameters
        self.batch_size = batch_size
        self.num_steps = max(num_steps//env.n_env, 1)
        self.num_epochs = num_epochs
        self.clip_epsilon = clip_epsilon
        self.gamma = gamma
        self.gae_lambda = gae_lambda

        # Loss coefficients
        self.max_grad_clip_norm = max_grad_clip_norm
        self.value_coef = value_coef
        self.ent_coef = ent_coef

        # Rollout storage with exact shapes from specification
        self.rollout_storage = RolloutStorage(
            num_steps=self.num_steps,
            num_envs=env.n_env,
            device=device
        )

        # Optimizer
        self.optimizer = optim.Adam([
            {'params': self.agent.policy_net.parameters()},
            # {'params': self.agent.embedder.parameters()}
        ], lr=learning_rate, eps=1e-5)
        self.scheduler = optim.lr_scheduler.StepLR(self.optimizer, step_size=100, gamma=0.75)

        self._last_obs = None
        self.writer = SummaryWriter(log_dir=f"{log_dir}/{uuid.uuid4().hex[:8]}")


    def collect_rollouts(self, num_steps=2048) -> Tuple[Dict[str, torch.Tensor], torch.Tensor]:
        """
        Collect rollouts for num_steps steps, независимо от длин эпизодов
        Поддерживает num_envs сред
        """
        obs = self._last_obs

        for step in range(num_steps):
            # Convert observations to tensors with exact shapes
            tensor_obs = self.agent.encode(obs)

            # Get action from policy and value from value network
            with torch.no_grad():
                actions, values, log_probs = self.agent(tensor_obs)

            # Take environment step
            next_obs, rewards, dones, infos = self.env.step(actions.cpu().numpy())
            rewards = torch.FloatTensor(rewards).to(self.device)
            dones = torch.FloatTensor(dones).to(self.device)

            # Store experience with exact shapes
            self.rollout_storage.add(
                obs=tensor_obs,
                action=actions,  # (N)
                log_prob=log_probs,  # (N,)
                value=values,  # (N,)
                reward=rewards,  # (N,)
                done=dones  # (N,)
            )
            obs = next_obs

        # Get final values for bootstrapping
        with torch.no_grad():
            tensor_obs = self.agent.encode(obs)
            next_values = self.agent.predict_values(tensor_obs).squeeze(-1)  # (N,)

        self.rollout_storage.compute_returns_and_advantages(
            next_values=next_values,
            gamma=self.gamma,
            gae_lambda=self.gae_lambda
        )

        self._last_obs = obs

        return True


    def compute_loss(self, batch: Rollout) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Compute PPO loss for a minibatch с использованием обеих сетей"""
        # Get current policy predictions
        values, log_prob, entropy = self.agent.evaluate_actions(batch.observations, batch.actions)
        advantages = batch.advantages  # (mb_size,)

        # Policy loss (PPO clip)
        ratio = torch.exp(log_prob - batch.old_log_probs)  # (mb_size,)

        surr1 = ratio * advantages
        surr2 = torch.clamp(ratio, 1.0 - self.clip_epsilon, 1.0 + self.clip_epsilon) * advantages
        policy_loss = -torch.min(surr1, surr2).mean()

        # Value loss (MSE с 0.5 множителем)
        value_loss = 0.5 * (batch.returns - values).pow(2).mean()

        # Entropy bonus
        entropy_loss = -entropy.mean()

        # Total loss
        total_loss = (policy_loss +
                      self.value_coef * value_loss +
                      self.ent_coef * entropy_loss)

        # Additional metrics
        clip_fraction = ((ratio - 1.0).abs() > self.clip_epsilon).float().mean()
        approx_kl = (batch.old_log_probs - log_prob).mean()

        loss_info = {
            'policy_loss': policy_loss.item(),
            'value_loss': value_loss.item(),
            'entropy_loss': entropy_loss.item(),
            'total_loss': total_loss.item(),
            'clip_fraction': clip_fraction.item(),
            'approx_kl': approx_kl.item(),
        }

        return total_loss, loss_info


    def update_policy(self):
        epoch_losses = defaultdict(list)

        for epoch in range(self.num_epochs):
            for minibatch in self.rollout_storage.get_minibatches(self.batch_size):
                # Compute loss
                loss, loss_info = self.compute_loss(minibatch)

                # Backward pass
                self.optimizer.zero_grad()
                loss.backward()
                grad_norm = torch.nn.utils.clip_grad_norm_(
                    list(self.agent.policy_net.parameters()),
                    self.max_grad_clip_norm
                )
                self.optimizer.step()

                # Store metrics
                loss_info['grad_norm'] = grad_norm.item()
                for key, value in loss_info.items():
                    epoch_losses[key].append(value)

        self.scheduler.step()
        # Return average metrics
        return {key: np.mean(values) for key, values in epoch_losses.items()}


    def train(self, total_timesteps: int = 100000):
        """Main training loop following the specified algorithm"""
        best_mean_reward = -float('inf')
        timestep = 0
        iteration = 0
        self._last_obs, _ = self.env.reset()
        while timestep < total_timesteps:
            iteration += 1

            # 1.1) Collect rollouts
            self.collect_rollouts(self.num_steps)
            timestep += self.batch_size

            # 1.2) Compute loss and
            # 1.3) Backprop via minibatches:
            info = self.update_policy()

            # 2) Evaluation
            if iteration % 10 == 0:
                metrics = evaluate_policy(
                    agent=self.agent,
                    env=self.test_env,
                    n_eval_episodes=self.test_env.n_env,
                    deterministic=True
                )
                info.update(metrics)
                info["learning_rate"] = self.scheduler.get_last_lr()[0]
                print(f"Iteration: {iteration}, Timestep: {timestep}")
                print(f"Mean reward: {info['mean_reward']:.2f}")

                if info['mean_reward'] > best_mean_reward:
                    best_mean_reward = info['mean_reward']
                    self.save_model(f"{self.writer.log_dir}/best_model.pth")
                    print(f"New best model saved with reward: {best_mean_reward:.2f}")

            for k, v in info.items():
                self.writer.add_scalar(k,  v, timestep)
            
            # Clear rollouts for next iteration
            self.rollout_storage.clear()


    def save_model(self, path: str):
        """Save model weights"""
        torch.save({
            'policy_state_dict': self.agent.policy_net.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, path)


    def load_model(self, path: str):
        """Load model weights"""
        checkpoint = torch.load(path, map_location=self.device)
        self.policy_net.load_state_dict(checkpoint['policy_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
