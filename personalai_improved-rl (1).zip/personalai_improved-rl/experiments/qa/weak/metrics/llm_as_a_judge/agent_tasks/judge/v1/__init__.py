from .suite import LLMJUDGE_SUITE_V1
