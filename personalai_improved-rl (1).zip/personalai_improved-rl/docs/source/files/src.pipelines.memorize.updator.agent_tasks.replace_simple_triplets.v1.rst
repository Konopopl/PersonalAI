src.pipelines.memorize.updator.agent\_tasks.replace\_simple\_triplets.v1 package
================================================================================

Submodules
----------

src.pipelines.memorize.updator.agent\_tasks.replace\_simple\_triplets.v1.parsers module
---------------------------------------------------------------------------------------

.. automodule:: src.pipelines.memorize.updator.agent_tasks.replace_simple_triplets.v1.parsers
   :members:
   :undoc-members:
   :show-inheritance:

src.pipelines.memorize.updator.agent\_tasks.replace\_simple\_triplets.v1.prompts module
---------------------------------------------------------------------------------------

.. automodule:: src.pipelines.memorize.updator.agent_tasks.replace_simple_triplets.v1.prompts
   :members:
   :undoc-members:
   :show-inheritance:

src.pipelines.memorize.updator.agent\_tasks.replace\_simple\_triplets.v1.suite module
-------------------------------------------------------------------------------------

.. automodule:: src.pipelines.memorize.updator.agent_tasks.replace_simple_triplets.v1.suite
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.pipelines.memorize.updator.agent_tasks.replace_simple_triplets.v1
   :members:
   :undoc-members:
   :show-inheritance:
