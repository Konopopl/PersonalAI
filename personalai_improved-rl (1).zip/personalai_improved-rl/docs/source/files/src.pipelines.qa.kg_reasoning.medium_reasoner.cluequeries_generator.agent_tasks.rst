src.pipelines.qa.kg\_reasoning.medium\_reasoner.cluequeries\_generator.agent\_tasks package
===========================================================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.pipelines.qa.kg_reasoning.medium_reasoner.cluequeries_generator.agent_tasks.query_generator

Module contents
---------------

.. automodule:: src.pipelines.qa.kg_reasoning.medium_reasoner.cluequeries_generator.agent_tasks
   :members:
   :undoc-members:
   :show-inheritance:
