src.pipelines.memorize.updator.agent\_tasks package
===================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.pipelines.memorize.updator.agent_tasks.replace_simple_triplets
   src.pipelines.memorize.updator.agent_tasks.replace_thesis_triplets

Module contents
---------------

.. automodule:: src.pipelines.memorize.updator.agent_tasks
   :members:
   :undoc-members:
   :show-inheritance:
