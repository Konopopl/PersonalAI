src.kg\_model.graph\_model package
==================================

Submodules
----------

src.kg\_model.graph\_model.GraphModel module
--------------------------------------------

.. automodule:: src.kg_model.graph_model.GraphModel
   :members:
   :undoc-members:
   :show-inheritance:

src.kg\_model.graph\_model.config module
----------------------------------------

.. automodule:: src.kg_model.graph_model.config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.kg_model.graph_model
   :members:
   :undoc-members:
   :show-inheritance:
