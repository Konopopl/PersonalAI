src.pipelines.memorize.updator.agent\_tasks.replace\_thesis\_triplets package
=============================================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.pipelines.memorize.updator.agent_tasks.replace_thesis_triplets.v1

Submodules
----------

src.pipelines.memorize.updator.agent\_tasks.replace\_thesis\_triplets.general\_parsers module
---------------------------------------------------------------------------------------------

.. automodule:: src.pipelines.memorize.updator.agent_tasks.replace_thesis_triplets.general_parsers
   :members:
   :undoc-members:
   :show-inheritance:

src.pipelines.memorize.updator.agent\_tasks.replace\_thesis\_triplets.selector module
-------------------------------------------------------------------------------------

.. automodule:: src.pipelines.memorize.updator.agent_tasks.replace_thesis_triplets.selector
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.pipelines.memorize.updator.agent_tasks.replace_thesis_triplets
   :members:
   :undoc-members:
   :show-inheritance:
