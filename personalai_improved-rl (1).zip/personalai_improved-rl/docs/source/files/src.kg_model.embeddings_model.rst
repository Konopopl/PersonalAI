src.kg\_model.embeddings\_model package
=======================================

Submodules
----------

src.kg\_model.embeddings\_model.EmbeddingsModel module
------------------------------------------------------

.. automodule:: src.kg_model.embeddings_model.EmbeddingsModel
   :members:
   :undoc-members:
   :show-inheritance:

src.kg\_model.embeddings\_model.config module
---------------------------------------------

.. automodule:: src.kg_model.embeddings_model.config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.kg_model.embeddings_model
   :members:
   :undoc-members:
   :show-inheritance:
