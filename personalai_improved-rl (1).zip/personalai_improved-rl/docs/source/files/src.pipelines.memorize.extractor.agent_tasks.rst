src.pipelines.memorize.extractor.agent\_tasks package
=====================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.pipelines.memorize.extractor.agent_tasks.thesis_extraction
   src.pipelines.memorize.extractor.agent_tasks.triplet_extraction

Module contents
---------------

.. automodule:: src.pipelines.memorize.extractor.agent_tasks
   :members:
   :undoc-members:
   :show-inheritance:
