src.pipelines.qa.kg\_reasoning.weak\_reasoner.query\_parser.agent\_tasks package
================================================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.pipelines.qa.kg_reasoning.weak_reasoner.query_parser.agent_tasks.kw_extraction

Module contents
---------------

.. automodule:: src.pipelines.qa.kg_reasoning.weak_reasoner.query_parser.agent_tasks
   :members:
   :undoc-members:
   :show-inheritance:
