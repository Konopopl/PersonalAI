src.pipelines.qa.query\_preprocessing.decomposition package
===========================================================

Submodules
----------

src.pipelines.qa.query\_preprocessing.decomposition.QueryDecomposer module
--------------------------------------------------------------------------

.. automodule:: src.pipelines.qa.query_preprocessing.decomposition.QueryDecomposer
   :members:
   :undoc-members:
   :show-inheritance:

src.pipelines.qa.query\_preprocessing.decomposition.config module
-----------------------------------------------------------------

.. automodule:: src.pipelines.qa.query_preprocessing.decomposition.config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.pipelines.qa.query_preprocessing.decomposition
   :members:
   :undoc-members:
   :show-inheritance:
