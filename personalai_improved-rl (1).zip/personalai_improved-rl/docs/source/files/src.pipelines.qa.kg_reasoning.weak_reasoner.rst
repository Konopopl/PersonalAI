src.pipelines.qa.kg\_reasoning.weak\_reasoner package
=====================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.pipelines.qa.kg_reasoning.weak_reasoner.answer_generator
   src.pipelines.qa.kg_reasoning.weak_reasoner.knowledge_comparator
   src.pipelines.qa.kg_reasoning.weak_reasoner.knowledge_retriever
   src.pipelines.qa.kg_reasoning.weak_reasoner.query_parser

Submodules
----------

src.pipelines.qa.kg\_reasoning.weak\_reasoner.WeakKGReasoner module
-------------------------------------------------------------------

.. automodule:: src.pipelines.qa.kg_reasoning.weak_reasoner.WeakKGReasoner
   :members:
   :undoc-members:
   :show-inheritance:

src.pipelines.qa.kg\_reasoning.weak\_reasoner.config module
-----------------------------------------------------------

.. automodule:: src.pipelines.qa.kg_reasoning.weak_reasoner.config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.pipelines.qa.kg_reasoning.weak_reasoner
   :members:
   :undoc-members:
   :show-inheritance:
