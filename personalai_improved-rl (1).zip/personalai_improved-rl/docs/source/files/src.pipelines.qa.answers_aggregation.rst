src.pipelines.qa.answers\_aggregation package
=============================================

Submodules
----------

src.pipelines.qa.answers\_aggregation.AnswersAggregator module
--------------------------------------------------------------

.. automodule:: src.pipelines.qa.answers_aggregation.AnswersAggregator
   :members:
   :undoc-members:
   :show-inheritance:

src.pipelines.qa.answers\_aggregation.config module
---------------------------------------------------

.. automodule:: src.pipelines.qa.answers_aggregation.config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.pipelines.qa.answers_aggregation
   :members:
   :undoc-members:
   :show-inheritance:
