src.pipelines.qa.kg\_reasoning.medium\_reasoner.entities2nodes\_matching package
================================================================================

Submodules
----------

src.pipelines.qa.kg\_reasoning.medium\_reasoner.entities2nodes\_matching.Entities2NodesMatcher module
-----------------------------------------------------------------------------------------------------

.. automodule:: src.pipelines.qa.kg_reasoning.medium_reasoner.entities2nodes_matching.Entities2NodesMatcher
   :members:
   :undoc-members:
   :show-inheritance:

src.pipelines.qa.kg\_reasoning.medium\_reasoner.entities2nodes\_matching.config module
--------------------------------------------------------------------------------------

.. automodule:: src.pipelines.qa.kg_reasoning.medium_reasoner.entities2nodes_matching.config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.pipelines.qa.kg_reasoning.medium_reasoner.entities2nodes_matching
   :members:
   :undoc-members:
   :show-inheritance:
