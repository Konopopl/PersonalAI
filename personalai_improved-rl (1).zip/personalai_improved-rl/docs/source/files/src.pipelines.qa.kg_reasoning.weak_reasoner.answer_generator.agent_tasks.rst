src.pipelines.qa.kg\_reasoning.weak\_reasoner.answer\_generator.agent\_tasks package
====================================================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.pipelines.qa.kg_reasoning.weak_reasoner.answer_generator.agent_tasks.ag

Module contents
---------------

.. automodule:: src.pipelines.qa.kg_reasoning.weak_reasoner.answer_generator.agent_tasks
   :members:
   :undoc-members:
   :show-inheritance:
