.. personal_ai documentation master file, created by
   sphinx-quickstart on Tue Nov 12 00:58:49 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Personal AI документация
=========================


.. toctree::
   :maxdepth: 1
   :caption: Contents:

   files/modules

   .. pages/architecture_page
   .. pages/components_page
   .. pages/examples_page
   .. pages/environment_page

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
