src.pipelines.qa.knowledge\_comparator package
==============================================

Submodules
----------

src.pipelines.qa.knowledge\_comparator.KnowledgeComparator module
-----------------------------------------------------------------


.. autoclass:: src.pipelines.qa.knowledge_comparator.KnowledgeComparator.KnowledgeComparatorConfig()
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: src.pipelines.qa.knowledge_comparator.KnowledgeComparator.KnowledgeComparator()
   :members:
   :undoc-members:
   :show-inheritance:
