Available Triplets Filters
==========================

.. image:: ../../../class_diagram/available_triplets_filters.png
  :width: 800
  :align: center

src.pipelines.qa.knowledge\_retriever package
---------------------------------------------

src.pipelines.qa.knowledge\_retriever.TripletsFilter module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: src.pipelines.qa.knowledge_retriever.TripletsFilter.TripletsFilterConfig()
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: src.pipelines.qa.knowledge_retriever.TripletsFilter.TripletsFilter()
   :members:
   :undoc-members:
   :show-inheritance:
