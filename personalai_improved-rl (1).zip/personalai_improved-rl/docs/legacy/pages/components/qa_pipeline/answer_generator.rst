Answer Generator
================

.. image:: ../../../class_diagram/qallmgenerator.png
  :width: 800
  :align: center

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   src/src.pipelines.qa.answer_generator
