Query Parser
============

.. image:: ../../../class_diagram/query_llm_parser.png
  :width: 800
  :align: center

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   src/src.pipelines.qa.query_parser
