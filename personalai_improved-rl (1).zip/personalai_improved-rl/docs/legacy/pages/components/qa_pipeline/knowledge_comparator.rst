Knowledge Comparator
====================

.. image:: ../../../class_diagram/knowledge_comparator.png
  :width: 800
  :align: center

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   src/src.pipelines.qa.knowledge_comparator
