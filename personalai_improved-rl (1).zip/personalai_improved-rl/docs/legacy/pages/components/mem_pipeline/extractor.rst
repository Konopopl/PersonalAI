Memory Extractor
================

.. image:: ../../../class_diagram/llm_extractor.png
  :width: 800
  :align: center


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   src/src.pipelines.memorize.extractor.rst
