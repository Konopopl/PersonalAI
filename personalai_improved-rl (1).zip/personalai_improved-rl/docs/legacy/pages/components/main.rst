PersonalAI Main
===============

.. image:: ../../class_diagram/personal_ai.png
  :width: 700
  :align: center

src.personalai\_main module
---------------------------

.. autoclass:: src.personalai_main.PersonalAIConfig()
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: src.personalai_main.PersonalAI()
   :members:
   :undoc-members:
   :show-inheritance:
