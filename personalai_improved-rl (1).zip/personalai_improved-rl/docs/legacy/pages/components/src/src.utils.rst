src.utils package
=================

Submodules
----------

src.utils.data\_structs module
------------------------------

.. automodule:: src.utils.data_structs
   :members:
   :undoc-members:
   :show-inheritance:

src.utils.task\_solver module
------------------------------

.. automodule:: src.utils.task_solver
   :members:
   :undoc-members:
   :show-inheritance:

src.utils.errors module
-----------------------

.. automodule:: src.utils.errors
   :members:
   :undoc-members:
   :show-inheritance:


src.utils.language\_detector module
-----------------------------------

.. automodule:: src.utils.language_detector
   :members:
   :undoc-members:
   :show-inheritance:

src.utils.logger module
-----------------------

.. automodule:: src.utils.logger
   :members:
   :undoc-members:
   :show-inheritance:
