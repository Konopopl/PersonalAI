src.parsers.memorize\_pipeline package
======================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.parsers.memorize_pipeline.extractor
   src.parsers.memorize_pipeline.updator
