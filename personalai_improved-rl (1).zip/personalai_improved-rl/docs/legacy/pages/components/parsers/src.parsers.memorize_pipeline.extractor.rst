src.parsers.memorize\_pipeline.extractor package
================================================

Submodules
----------

src.parsers.memorize\_pipeline.extractor.thesis\_extraction module
------------------------------------------------------------------

.. automodule:: src.parsers.memorize_pipeline.extractor.thesis_extraction
   :members:
   :undoc-members:
   :show-inheritance:

src.parsers.memorize\_pipeline.extractor.triplet\_extraction module
-------------------------------------------------------------------

.. automodule:: src.parsers.memorize_pipeline.extractor.triplet_extraction
   :members:
   :undoc-members:
   :show-inheritance:
