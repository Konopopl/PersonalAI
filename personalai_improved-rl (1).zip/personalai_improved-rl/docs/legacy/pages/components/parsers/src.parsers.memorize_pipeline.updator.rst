src.parsers.memorize\_pipeline.updator package
==============================================

Submodules
----------

src.parsers.memorize\_pipeline.updator.replace\_simple\_triplets module
-----------------------------------------------------------------------

.. automodule:: src.parsers.memorize_pipeline.updator.replace_simple_triplets
   :members:
   :undoc-members:
   :show-inheritance:

src.parsers.memorize\_pipeline.updator.replace\_thesis\_triplets module
-----------------------------------------------------------------------

.. automodule:: src.parsers.memorize_pipeline.updator.replace_thesis_triplets
   :members:
   :undoc-members:
   :show-inheritance:
