Опишем примерное расширение MediumReasoner'а элементами InstructionRag. Пункты 1-2 более-менее очевидны, за исключением техники построения instruction graph (вопрос реализации).
Пункты 4-6 даны в дополнение, на подумать.

При этом IG должен быть отдельной структурой, независимой от исходного графа знаний:  IG — это не о том, "что есть", а о том, "как узнать". 
Это разные типы знаний, их смешение приведет к загрязнению фактологических данных мета-информацией и усложнит управление графом.

---

## Предлагаемая интеграция InstructRAG в MediumKGReasoner

### 1. **Заменить/Расширить SearchPlanEnhancer компонентами InstructRAG**
Текущий `SearchPlanEnhancer` генерирует линейный план. Вместо этого можно использовать элементы **InstructRAG** для:
- Декомпозиции пользовательского запроса на подвопросы.
- Поиска и комбинирования путей инструкций из предварительно построенного графа инструкций **instruction graph**.
- Использования агентов **RL-Agent** и **ML-Agent** для динамической генерации и уточнения плана поиска.

#### Изменения в `MediumKGReasonerConfig`:
```python
@dataclass
class MediumKGReasonerConfig(BaseKGReasonerConfig):
    # Добавить специфичные для InstructRAG конфигурации
    use_instruct_rag: bool = True
    instruction_graph_path: str = None
    rag_threshold: float = ...
    num_candidate_paths: int = ...
    # ... другие существующие конфиги
```

#### Изменения в `MediumKGReasoner`:
```python
def __init__(self, kg_model: KnowledgeGraphModel, config: MediumKGReasonerConfig, ...):
    super().__init__(...)
    if config.use_instruct_rag:
        self.instruction_graph = load_instruction_graph(config.instruction_graph_path)
        self.rl_agent = RLRAGAgent(config)
        self.ml_agent = MLRAGAgent(config)
    # ... другие инициализации
```

---

### 2. **Модифицировать метод `update_searchplan`**
Вместо использования оригинального `SearchPlanEnhancer`, использовать элементы InstructRAG для генерации/уточнения плана поиска:

```python
def update_searchplan(self, search_step: int, search_plan: SearchPlanInfo) -> Tuple[SearchPlanInfo, ReturnInfo]:
    if self.config.use_instruct_rag:
        # Найти candidate paths с помощью агента RL-Agent
        candidate_paths = self.rl_agent.retrieve_paths(search_plan.base_query, self.instruction_graph)
        # Выбрать лучший путь с помощью агента ML-Agent
        best_path = self.ml_agent.select_path(search_plan.base_query, candidate_paths)
        # Конвертировать best_path (последовательность инструкций) в шаги поиска ???
        search_plan.search_steps = # self.convert_path_to_search_steps(best_path)
        rinfo = ReturnInfo(ReturnStatus.success)
    else:
        search_plan, rinfo = self.searchplan_enhancer.perform(search_step, search_plan)
    return search_plan, rinfo
```

---

### 3. **??? Улучшить сопоставление сущностей с учётом инструкций ???** 
Пути инструкций из InstructRAG могут направлять (улучшать) процесс сопоставления сущностей:

```python
def match_searchstep_to_kg(self, search_query: str) -> Tuple[Dict[str, List[VectorDBInstance]], ReturnInfo]:
    if self.config.use_instruct_rag:
        # Использовать instruction-aware извлечение сущностей ???
        entities, rinfo = self.rag_aware_entity_extractor.perform(search_query)
    else:
        entities, rinfo = self.entities_extractor.perform(search_query)
    # ... 
```

---

### 4. **??? Использовать пути инструкций для направления обхода графа знаний ???**
Пути из InstructRAG могут заменить или дополнить генерацию clue-запросов:

```python
def get_cluequeries(self, search_query: str, matched_kg_objects: Dict[...]) -> Tuple[List[QueryInfo], ReturnInfo]:
    if self.config.use_instruct_rag:
        # Сгенерировать clue queries на основе пути инструкций
        cluequeries = self.generate_clue_queries_from_path(best_path, matched_kg_objects)
        rinfo = ReturnInfo(ReturnStatus.success)
    else:
        cluequeries, rinfo = self.cluequeries_generator.perform(search_query, matched_kg_objects)
    return cluequeries, rinfo
```

---

### 5.  **??? Добавить Meta-Learning для few-shot адаптации ???**
Методику few-shot обучение из InstructRAG (см. статью) можно использовать для адаптации ризонера к новым задачам:

```python
def adapt_to_new_task(self, support_set: List[Tuple[str, str]]):
    # Расширить instruction graph новыми примерами
    self.instruction_graph = extend_graph(self.instruction_graph, support_set)
    # Дообучить RL-Agent и ML-Agent на новой задаче
    ...
```

---

### 6. **??? Кешировать и повторно использовать пути инструкций ???**
Использовать instruction graph как кеш для похожих запросов:

```python
@CacheUtils.cache_method_output
def perform(self, query: str) -> Tuple[str, ReturnInfo]:
    if self.config.use_instruct_rag:
        # Проверить, существует ли путь в графе для этого запроса
        cached_path = self.instruction_graph.get_cached_path(query)
        if cached_path:
            # Использовать кешированный путь для ускорения планирования
            search_plan = self.build_plan_from_path(cached_path)
    # ...
```

---

##  Преимущества после интеграции

- **Улучшенное планирование**: InstructRAG предоставляет более структурированные и переиспользуемые пути инструкций.
- **Улучшенная генерализация**: Meta-learning позволяет адаптироваться к новым задачам.
- **Устойчивость к шуму**: Instruction graph может помогать отфильтровывать нерелевантные пути.
- **Эффективность**: Кеширование и повторное использование путей инструкций уменьшает избыточные вычисления.

---

##  Тестирование, оценка

- Сравнить производительность на HotpotQA, ALFWorld и др. с использованием InstructRAG и без него.
- Измерить точность планирования, релевантность поиска и качество ответов.
- Оценить скорость и эффективность few-shot адаптации ???.

---