# Deployment instructions for RL experiments

From this directory:

## Start database related containers and LLM agent (if they are not exist or need to be recreated)
```
docker compose --env-file  /mnt/data/pai_improved/hotpotqa/llama318b_221025_v2prompts/.env up -d ollama_agent milvus neo4j opensearch
```


## Start your workspace 
1. Change `COMPOSE_PROJECT_NAME`,  `WORKSPACE_JUPYTER_PORT`, `WORKSPACE_TENSORBOARD_PORT` to your own unique values. 
   In case of problems, ensure `SHARED_NETWORK` is correct with respect to database `.env` file, set `GPU_DEVICES`. 
2. Run and wait for installing packages
```
docker compose --env-file .env_base up -d workspace
```
